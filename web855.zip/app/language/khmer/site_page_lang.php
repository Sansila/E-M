
<?php
    $lang['home'] = "ទំព័រដើម";
    $lang['SERVICES']="សេវាកម្ម";
    $lang['department_photo'] = "រូបថតថ្នាក់ដឹកនាំ";
    $lang['leadership'] = "ថ្នាក់ដឹកនាំ";
    $lang['other_institution'] = "ស្ថាប័នផ្សេងៗ";
    $lang['event_gallery'] = "បណ្តុំរូបថត";
    $lang['news_events'] = "ព្រឹត្តិការណ៍នាៗ";
    $lang['latest_news'] = "ព័ត៌មានថ្មីៗ";
    $lang['latest_videos'] = "វីដេអូ";
    $lang['general_director'] = "អគ្គនាយក";
    $lang['view_all'] = "បន្តែមទៀត";


    //footer
    $lang['address'] = "អាសយដ្ធាន";
    $lang['where_are_we'] = "យើងនៅឯណា?";
    $lang['like_us'] = "ឡាយ៍ អឹស៍";
    $lang['all_right_reserved'] = "រក្សាសិទ្ធិគ្រប់យ៉ាងដោយ";
?>