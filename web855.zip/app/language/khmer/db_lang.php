<?php
    $lang['home'] = "ទំព័រដើម";
?>