
<?php
  $lang['home'] = "Home";
  $lang['department_photo'] = "Department Photo";
  $lang['leadership'] = "Leadership";	
  $lang['other_institution'] = "Other Institutions";
  $lang['event_gallery'] = "Event Gallery";
  $lang['news_events'] = "News And Events";
  $lang['latest_news'] = "Latest News";
  $lang['latest_videos'] = "Latest Videos";
  $lang['general_director'] = "General Director";
  $lang['view_all'] = "View All";

  //footer
  $lang['address'] = "Address";
  $lang['where_are_we'] = "Where Are We?";
  $lang['like_us'] = "Like Us";
  $lang['all_right_reserved'] = "All Rights Reserved";
?>