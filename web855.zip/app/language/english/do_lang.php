<?php
    $lang['home'] = "Home";
	
?>