<div class="parallax-window inner-banner tc-padding overlay-dark tc-paddings " data-parallax="scroll" data-image-src="images/inner-banner/img-06.jpg">
            <div class="container">
                <div class="inner-page-heading h-white style-2">
                    <h2 ><?php  echo $row->article_title;?></h2>
                    
                </div>
            </div>
        </div>
        <!-- Inner Banner -->

    </header>
    <!-- Header -->


    <!-- Main Content -->
    <main class="main-content" style="background-color: #fff">

        <!-- Gallery -->
        <div class="gallery tc-padding" style="background-color: #fff">
            <div class="container">
                <div class="table-responsive" style="padding: 10px;">
                    
                    <?php  echo $row->content;?>
                <!-- <div class="col-sm-12 col-xs-12" style="border: 1px solid #ddd;">
                    
                
            </div> -->
                </div>
                
        </div>
        <!-- Gallery -->

    </main>