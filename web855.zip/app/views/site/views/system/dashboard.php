<div class="container">
	<div class="row">
		<div class="col-md-12" align="center">
			<div style="margin-top:50px;">
				<img src="<?=base_url().'assets/upload/army_big_logo.png'?>" width="50%" style="margin-left:-200px;">
			</div>
		</div>
	</div>
</div>