<div class="parallax-window inner-banner tc-paddings overlay-dark" data-parallax="scroll" >
            <div class="container">
                <div class="inner-page-heading h-white style-2">
                    <h2>Contact Us</h2>
                    <!-- <p> Spanning fifteen years of work, Everywhere I Look is a book full of unexpected moments,</p> -->
                </div>
            </div>
        </div>
        <!-- Inner Banner -->

    </header>
    <!-- Header -->
    <main class="main-content">

        <!-- Contant Holder -->
        <div class="tc-padding">
            <div class="container">

                

                <!-- Contact Map -->
                <div class="tc-padding-bottom" style="padding-bottom: 20px;">
                    <!-- <div id="contant-map" class="contant-map"> -->
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d69425.25809105227!2d104.91882251926587!3d11.53685956462248!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTHCsDMyJzAyLjIiTiAxMDTCsDU2JzI5LjUiRQ!5e0!3m2!1sen!2skh!4v1519719665217" width="100%" height="660" frameborder="0" style="border:0" allowfullscreen></iframe>
                    <!-- </div> -->
                </div>
                <!-- Contact Map -->
                <!-- Address Columns -->
                <div class="tc-padding-bottom">
                    <div class="row">
                
                        <!-- Column -->
                        <div class="col-lg-3 col-xs-6 r-full-width">
                            <div class="address-column">
                                <span class="address-icon"><i class="fa fa-map-marker"></i></span>
                                <h6>Address</h6>
                                <strong>855 SOLUTION</strong>
                                <p>#418Eo+E1, Phlauv 358, Sangkat Chbar Ampov, Khan Chbar Ampov , Phnom Penh , Cambodia.</p>
                            </div>
                        </div>
                        <!-- Column -->

                        <!-- Column -->
                        <div class="col-lg-3 col-xs-6 r-full-width">
                            <div class="address-column">
                                <span class="address-icon"><i class="fa fa-volume-control-phone"></i></span>
                                <h6>Hotline</h6>
                                <strong>(+855)10 871 787 / 96 446 4486</strong>
                                <!-- <p>Habitasse venenatis dictum sed habitant taciti fermentum cras himenaeos nunc et erat blandit at,</p> -->
                            </div>
                        </div>
                        <!-- Column -->

                        <!-- Column -->
                        <div class="col-lg-3 col-xs-6 r-full-width">
                            <div class="address-column">
                                <span class="address-icon"><i class="fa fa-envelope"></i></span>
                                <h6>Email</h6>
                                <strong>info@855solution.com</strong>
                                <!-- <p>Habitasse venenatis dictum sed habitant taciti fermentum cras himenaeos nunc et erat blandit at,</p> -->
                            </div>
                        </div>
                        <!-- Column -->

                        <!-- Column -->
                        <div class="col-lg-3 col-xs-6 r-full-width">
                            <div class="address-column">
                                <span class="address-icon"><i class="fa fa-calendar"></i></span>
                                <h6>Calendar</h6>
                                <strong>WORKING HOURS</strong>
                                <p>Mon – Fri : 8:00 AM – 17:00 PM Saturday : 8:00 AM – 12:00 PM</p>
                            </div>
                        </div>
                        <!-- Column -->

                    </div>
                </div>
                <!-- Address Columns -->
                <!-- Form -->
               
                <!-- Form -->

            </div>
        </div>
        <!-- Contant Holder -->

    </main>