
            </div>
			<!-- <div class="row">
				<div class="col-xs-12" id="footer">
					2015 - 2016 &copy; E-Shopping Admin. Developed by <a href="https://www.greenict.comkh/">www.greenict.com.kh</a>
				</div> 
			</div>-->
		</div>
	</body>
</html>