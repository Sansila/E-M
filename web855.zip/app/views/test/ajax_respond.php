<?php
    
    //header("Content-type: text/x-json");
	$data['re']=1;
	echo json_encode($data);
	die();
?>